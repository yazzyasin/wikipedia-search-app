let searchip = document.getElementById('searchInput');
let searchrslt = document.getElementById("searchResults");
let spin = document.getElementById("spinner");

function createandappend(result) {
    let {
        title,
        link,
        description
    } = result;
    let resultitem = document.createElement("div");
    resultitem.classList.add("mb-5");
    searchrslt.appendChild(resultitem);

    let titleEl = document.createElement("a");
    titleEl.href = link;
    titleEl.textContent = title;
    titleEl.target = "_blank";
    titleEl.classList.add("text-[22px]", "hover:underline", "text-[#007bff]");
    resultitem.appendChild(titleEl);

    let breakEl = document.createElement("br");
    resultitem.appendChild(breakEl);

    let urlEl = document.createElement("a");
    urlEl.href = link;
    urlEl.textContent = link;
    urlEl.target = "_blank";
    urlEl.classList.add("no-underline", "text-[#006621]");
    resultitem.appendChild(urlEl);

    let descriptionEl = document.createElement("p");
    descriptionEl.textContent = description;
    descriptionEl.classList.add("text-[#444444]", "text-sm", "mt-1");
    resultitem.appendChild(descriptionEl);
}

function display(search_results) {
    spin.classList.toggle("d-none");
    for (let result of search_results) {
        createandappend(result);
    }
}

function searchwiki(event) {
    if (event.key === "Enter") {
        spin.classList.toggle("d-none");
        searchrslt.textContent = "";
        let ip = searchip.value;
        let url = "https://apis.ccbp.in/wiki-search?search=" + ip;
        let options = {
            method: "GET"
        };
        fetch(url, options)
            .then(function(response) {
                return response.json();
            })
            .then(function(jsondata) {
                const {
                    search_results
                } = jsondata;
                display(search_results);
            });
    }
}
searchip.addEventListener("keydown", searchwiki);